package com.example.week5project

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.google.android.material.appbar.MaterialToolbar

class InventoryActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var adapter: InventoryAdapter
    private lateinit var repo: FirestoreInventoryRepository
    private var liveReg: ListenerRegistration? = null

    // === NEW: in-memory structures ===
    private var fullItems: List<InventoryItem> = emptyList()   // source of truth for filtering
    private var items: List<InventoryItem> = emptyList()
    private val byId = mutableMapOf<String, InventoryItem>()
    private val byName = mutableMapOf<String, MutableList<InventoryItem>>()

    // === NEW: search UI + debounce job
    private lateinit var searchEdit: TextInputEditText
    private var searchJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)
        val toolbar = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "Horrea Heroes"

        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: run {
            finish()
            return
        }
        repo = FirestoreInventoryRepository(uid)  // repo emits sorted list now (case-insensitive):contentReference[oaicite:0]{index=0}

        recycler = findViewById(R.id.inventoryRecyclerView)
        recycler.layoutManager = LinearLayoutManager(this)

        adapter = InventoryAdapter(
            onDelete = { item ->
                lifecycleScope.launch {
                    try { repo.deleteItem(item) }
                    catch (e: FirebaseFirestoreException) {
                        Log.e("Firestore", "Error deleting item: ", e)
                        Toast.makeText(this@InventoryActivity, "Error deleting item.", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            onChange = { item ->
                lifecycleScope.launch {
                    try { repo.updateItem(item) }
                    catch (e: FirebaseFirestoreException) {
                        Log.e("Firestore", "Error updating item: ", e)
                    }
                }
            }
        )
        recycler.adapter = adapter  // continues to use ListAdapter for recycler

        val addBtn: Button = findViewById(R.id.addItemButton)
        val signOutBtn: Button = findViewById(R.id.signOutButton)
        addBtn.setOnClickListener { addItem() }
        signOutBtn.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            Toast.makeText(this, "Signed out", Toast.LENGTH_SHORT).show()
            finish()
        }

        // search box
        searchEdit = findViewById(R.id.searchEditText)
        searchEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty()
                searchJob?.cancel()
                searchJob = lifecycleScope.launch {
                    delay(250) // debounce
                    applyFilter(q)
                }
            }
        })

        // Listen for firestore changes
        liveReg = repo.listen { latestItems ->
            // Keep a full copy for filtering
            fullItems = latestItems

            // Rebuild hash maps from fullItems
            rebuildIndexes(fullItems)

            // Apply current filter
            applyFilter(searchEdit.text?.toString().orEmpty())
        } // list source from repo listener:contentReference[oaicite:2]{index=2}
    }

    override fun onDestroy() {
        super.onDestroy()
        liveReg?.remove()
    }

    private fun addItem() {
        lifecycleScope.launch {
            val newItem = InventoryItem(name = "New Item", quantity = 1)
            try { repo.addItem(newItem) }
            catch (e: FirebaseFirestoreException) {
                Log.e("Firestore", "Error adding item: ", e)
                Toast.makeText(this@InventoryActivity, "Error: Could not add item.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //filter logic
    private fun applyFilter(query: String) {
        val q = query.trim().lowercase()
        val filtered = if (q.isEmpty()) {
            fullItems
        } else {
            val maybeQty = q.toIntOrNull()
            fullItems.filter { item ->
                when {
                    // name contains q (case-insensitive)
                    item.name.lowercase().contains(q) -> true
                    // or if query is a number, match quantity exactly
                    maybeQty != null && item.quantity == maybeQty -> true
                    else -> false
                }
            }
        }

        // Keep list for adapter + indexes for fast lookup
        items = filtered
        rebuildIndexes(filtered)

        // Submit to adapter (ListAdapter diffing)
        adapter.submitList(filtered)
    }

    // rebuild hash maps
    private fun rebuildIndexes(src: List<InventoryItem>) {
        byId.clear()
        byName.clear()
        for (it in src) {
            it.id?.let { id -> byId[id] = it }
            val key = it.name.lowercase()
            byName.getOrPut(key) { mutableListOf() }.add(it)
        }
    }

    // Fast-lookup
    fun getItemById(id: String): InventoryItem? = byId[id]
    fun getItemsByName(name: String): List<InventoryItem> = byName[name.lowercase()].orEmpty()
}
