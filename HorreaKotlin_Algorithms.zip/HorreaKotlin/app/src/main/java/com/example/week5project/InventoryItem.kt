package com.example.week5project

data class InventoryItem(
    val id: String? = null,   // Firestore document ID
    var name: String = "",
    var quantity: Int = 0
)


