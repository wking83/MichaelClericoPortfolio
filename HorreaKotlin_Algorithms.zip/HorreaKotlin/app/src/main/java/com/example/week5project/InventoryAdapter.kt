package com.example.week5project

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class InventoryAdapter(
    private val onDelete: (item: InventoryItem) -> Unit,
    private val onChange: (item: InventoryItem) -> Unit
) : ListAdapter<InventoryItem, InventoryAdapter.VH>(DiffCallback()) {

    init {
        // Help RecyclerView keep viewholders stable as the list updates
        setHasStableIds(true)
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val name: EditText = view.findViewById(R.id.itemName)
        val qty: EditText = view.findViewById(R.id.itemQuantity)
        val deleteBtn: Button = view.findViewById(R.id.deleteRowButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.inventory_row, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)

        // Only set text if the field is NOT currently focused to avoid cursor jumps
        if (!holder.name.hasFocus()) holder.name.setText(item.name)
        if (!holder.qty.hasFocus()) holder.qty.setText(item.quantity.toString())

        // Update Firestore ONLY when focus is lost (no per-keystroke updates)
        holder.name.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val newName = holder.name.text?.toString().orEmpty()
                if (newName != item.name) onChange(item.copy(name = newName))
            }
        }

        holder.qty.onFocusChangeListener = View.OnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val newQty = holder.qty.text?.toString()?.toIntOrNull() ?: 0
                if (newQty != item.quantity) onChange(item.copy(quantity = newQty))
            }
        }

        holder.deleteBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onDelete(getItem(pos))
            }
        }
    }

    // Stable IDs so the same item keeps the same ViewHolder
    override fun getItemId(position: Int): Long {
        // Assuming InventoryItem.id is a String (e.g., Firestore doc id)
        return getItem(position).id.hashCode().toLong()
    }

    class DiffCallback : DiffUtil.ItemCallback<InventoryItem>() {
        override fun areItemsTheSame(oldItem: InventoryItem, newItem: InventoryItem): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: InventoryItem, newItem: InventoryItem): Boolean =
            oldItem == newItem
    }
}
