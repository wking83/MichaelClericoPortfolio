package com.example.week5project

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : AppCompatActivity() {

    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var createAccountButton: Button
    private lateinit var forgotPasswordButton: Button

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        auth = FirebaseAuth.getInstance()

        usernameEditText = findViewById(R.id.usernameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        createAccountButton = findViewById(R.id.createAccountButton)
        forgotPasswordButton = findViewById(R.id.forgotPasswordButton)

        // Login
        loginButton.setOnClickListener {
            val email = usernameEditText.text?.toString()?.trim().orEmpty()
            val pass  = passwordEditText.text?.toString()?.trim().orEmpty()
            if (email.isBlank() || pass.isBlank()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                try {
                    auth.signInWithEmailAndPassword(email, pass).await()
                    goToInventory()
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Invalid credentials", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // Create account
        createAccountButton.setOnClickListener {
            val email = usernameEditText.text?.toString()?.trim().orEmpty()
            val pass  = passwordEditText.text?.toString()?.trim().orEmpty()
            if (email.isBlank() || pass.isBlank()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                try {
                    auth.createUserWithEmailAndPassword(email, pass).await()
                    Toast.makeText(
                        this@MainActivity,
                        "Account created successfully!",
                        Toast.LENGTH_LONG
                    ).show()
                } catch (_: Exception) {
                    Toast.makeText(
                        this@MainActivity,
                        "User exists / create failed",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        // Forgot password
        forgotPasswordButton.setOnClickListener {
            val email = usernameEditText.text?.toString()?.trim().orEmpty()
            if (email.isBlank()) {
                Toast.makeText(this, "Enter your email above first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                try {
                    auth.sendPasswordResetEmail(email).await()
                    Toast.makeText(this@MainActivity, "Password reset email sent.", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Failed to send reset email.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Auto-skip if already signed in
        auth.currentUser?.let { goToInventory() }
    }

    private fun goToInventory() {
        startActivity(Intent(this@MainActivity, InventoryActivity::class.java))
        finish()
    }
}
