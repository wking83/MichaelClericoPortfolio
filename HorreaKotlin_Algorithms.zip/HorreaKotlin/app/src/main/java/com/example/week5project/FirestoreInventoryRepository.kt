package com.example.week5project

import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.ktx.Firebase
import com.google.firebase.firestore.ktx.firestore
import kotlinx.coroutines.tasks.await

class FirestoreInventoryRepository(uid: String) {

    private val col = Firebase.firestore
        .collection("users")
        .document(uid)
        .collection("items")

    // listen for real time updates
    fun listen(onChange: (List<InventoryItem>) -> Unit): ListenerRegistration {
        return col.orderBy("name").addSnapshotListener { snapshot, error ->
            if (error != null) {
                // In a real app, you would log this error or show a message
                return@addSnapshotListener
            }

            // If the snapshot is null, there's nothing to do
            if (snapshot == null) return@addSnapshotListener

            val out = mutableListOf<InventoryItem>()
            for (doc in snapshot.documents) {
                out.add(
                    InventoryItem(
                        id = doc.id, // Capture the document ID
                        name = doc.getString("name") ?: "",
                        quantity = (doc.getLong("quantity") ?: 0L).toInt()
                    )
                )
            }
            //sort ignoring upper lower
            val sorted = out.sortedBy { it.name.lowercase() }
            onChange(sorted) // Pass the updated list to the UI
        }
    }

    // Automatically picks up change when new item
    suspend fun addItem(item: InventoryItem) {
        col.add(
            mapOf(
                "name" to item.name,
                "quantity" to item.quantity,
            )
        ).await()
    }

    //update existing item
    suspend fun updateItem(item: InventoryItem) {
        item.id?.let {
            col.document(it).set(
                mapOf(
                    "name" to item.name,
                    "quantity" to item.quantity
                )
            ).await()
        }
    }

    //deletes item
    suspend fun deleteItem(item: InventoryItem) {
        item.id?.let {
            col.document(it).delete().await()
        }
    }
}